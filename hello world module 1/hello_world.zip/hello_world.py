# William Paddock
# Simple Hello World
# IT 210 Module 1

#Prints hello world
print("Hello World")