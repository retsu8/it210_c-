// William Paddock
// Simple Hello World
// IT 210 Module 1

// Get stream for the io write
#include <iostream>

// Main function to handle call c++
int main() {
    // Load the print statement into the std or std out to print to terminal
    std::cout << "Hello World!";
    // Close the script
    return 0;
}
